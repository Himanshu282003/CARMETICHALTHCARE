import { NavLink } from 'react-router-dom';
import { Activity, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <Activity className="h-8 w-8 text-blue-400" />
              <span className="text-xl font-bold text-white">
                Carmentis Healthcare
              </span>
            </div>
            <p className="text-slate-300 mb-6 text-sm leading-relaxed">
              Pioneering innovative medical solutions for diabetic, cardiac, and hypertension conditions.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-white">Quick Links</h4>
            <ul className="space-y-3 text-sm">
              <li>
                <NavLink
                  to="/"
                  className="text-slate-300 hover:text-white transition-colors"
                >
                  Home
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/products"
                  className="text-slate-300 hover:text-white transition-colors"
                >
                  Products
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/about"
                  className="text-slate-300 hover:text-white transition-colors"
                >
                  About Us
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/vision"
                  className="text-slate-300 hover:text-white transition-colors"
                >
                  Vision
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/contact"
                  className="text-slate-300 hover:text-white transition-colors"
                >
                  Contact
                </NavLink>
              </li>
            </ul>
          </div>

          {/* Product Categories */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-white">Products</h4>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="/products#diabetic" className="text-slate-300 hover:text-white transition-colors">
                  Diabetic Products
                </a>
              </li>
              <li>
                <a href="/products#cardiac" className="text-slate-300 hover:text-white transition-colors">
                  Cardiac Products
                </a>
              </li>
              <li>
                <a href="/products#hypertension" className="text-slate-300 hover:text-white transition-colors">
                  Hypertension Products
                </a>
              </li>
              <li>
                <a href="/products#general" className="text-slate-300 hover:text-white transition-colors">
                  General Products
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-white">Contact Us</h4>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-blue-400 mr-3 mt-0.5 flex-shrink-0" />
                <span className="text-slate-300 leading-relaxed">
                  Plot No - 79/9, Sunny Brooks, <br />
                  Sarjapur - Marathahalli Rd, <br />
                  Carmelaram, Hadosiddapura, <br />
                  Chikkakannalli, Bengaluru, <br />
                  Karnataka 560035
                </span>
              </li>
              <li className="flex items-start">
                <Phone className="h-5 w-5 text-blue-400 mr-3 mt-0.5 flex-shrink-0" />
                <div className="flex flex-col space-y-1">
                  <a href="tel:+919666688093" className="text-slate-300 hover:text-white transition-colors">
                    +91 96666 88093
                  </a>
                  <a href="tel:+918801921021" className="text-slate-300 hover:text-white transition-colors">
                    +91 88019 21021
                  </a>
                </div>
              </li>
              <li className="flex items-start">
                <Mail className="h-5 w-5 text-blue-400 mr-3 mt-0.5 flex-shrink-0" />
                <div className="flex flex-col space-y-1">
                  <a href="mailto:carmentis.care@gmail.com" className="text-slate-300 hover:text-white transition-colors">
                    carmentis.care@gmail.com
                  </a>
                  <a href="mailto:ordercarmentis@gmail.com" className="text-slate-300 hover:text-white transition-colors">
                    ordercarmentis@gmail.com
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-slate-400 text-sm">
            &copy; {new Date().getFullYear()} Carmentis Healthcare. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0 text-sm">
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}