import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

interface ProductCardProps {
  name: string;
  description: string;
  image?: string;
  category: string;
  delay?: number;
}

const ProductCard = ({ name, description, image, category, delay = 0 }: ProductCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="card card-hover overflow-hidden"
    >
      {image && (
        <div className="h-48 overflow-hidden">
          <img 
            src={image} 
            alt={name} 
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105" 
          />
        </div>
      )}
      <div className="p-6">
        <div className="mb-4">
          <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
            {category}
          </span>
        </div>
        <h3 className="text-lg font-semibold text-slate-900 mb-3">{name}</h3>
        <p className="text-slate-600 mb-4 text-sm leading-relaxed">{description}</p>
        <motion.button
          whileHover={{ x: 5 }}
          className="inline-flex items-center text-blue-600 font-medium hover:text-blue-700 text-sm"
        >
          Learn more <ArrowRight className="ml-1 h-4 w-4" />
        </motion.button>
      </div>
    </motion.div>
  );
};

export default ProductCard;