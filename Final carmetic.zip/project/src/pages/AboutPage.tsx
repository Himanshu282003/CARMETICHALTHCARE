import { motion } from 'framer-motion';
import { Activity, Users, Clock, Globe, Award, ArrowRight } from 'lucide-react';

const AboutPage = () => {
  const timeline = [
    {
      year: '2018',
      title: 'Company Founded',
      description: 'Carmentis Healthcare was established with a vision to transform medical treatment options.',
    },
    {
      year: '2019',
      title: 'First Product Launch',
      description: 'Introduction of our first cardiac medication, setting new standards in the industry.',
    },
    {
      year: '2020',
      title: 'Research Expansion',
      description: 'Opening of our state-of-the-art research facilities focused on diabetes management.',
    },
    {
      year: '2021',
      title: 'International Expansion',
      description: 'Products became available in over 25 countries, helping patients worldwide.',
    },
    {
      year: '2022',
      title: 'Innovation Award',
      description: 'Recognized for breakthrough advancements in hypertension treatment technology.',
    },
    {
      year: '2023',
      title: 'Next Generation Products',
      description: 'Launch of our most advanced pharmaceutical solutions for chronic condition management.',
    },
  ];

  return (
    <div className="pt-24 pb-20">
      {/* Header */}
      <section className="bg-gradient-to-r from-blue-700 to-blue-500 py-16 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">About Carmentis Healthcare</h1>
          <p className="text-blue-100 max-w-2xl">
            Pioneering innovative medical solutions with a patient-first approach to healthcare.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="md:w-1/2"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                Founded in 2019, Carmentis Healthcare emerged from a simple yet powerful vision: to develop pharmaceutical 
                products that not only treat symptoms but significantly improve quality of life for patients with chronic conditions.
              </p>
              <p className="text-gray-700 mb-4">
                Our founders, a team of medical researchers and healthcare professionals, recognized the gaps in treatment options 
                for diabetes, cardiac conditions, and hypertension. They set out to create solutions that were more effective, 
                caused fewer side effects, and were more accessible to patients worldwide.
              </p>
              <p className="text-gray-700 mb-4">
                Today, Carmentis Healthcare stands at the forefront of medical innovation, with a portfolio of products that 
                help millions of patients manage their health conditions effectively. Our commitment to research, quality, 
                and patient outcomes continues to drive everything we do.
              </p>
              
              <div className="grid grid-cols-2 gap-6 mt-8">
                <div className="flex flex-col items-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">15+</div>
                  <p className="text-gray-600 text-center">Years of Excellence</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">30+</div>
                  <p className="text-gray-600 text-center">Products Developed</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">45+</div>
                  <p className="text-gray-600 text-center">Countries Served</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">5M+</div>
                  <p className="text-gray-600 text-center">Patients Helped</p>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="md:w-1/2"
            >
              <div className="relative">
                <div className="absolute -top-4 -left-4 w-20 h-20 bg-blue-100 rounded-lg z-0"></div>
                <div className="absolute -bottom-4 -right-4 w-20 h-20 bg-cyan-100 rounded-lg z-0"></div>
                <img
                  src="https://images.pexels.com/photos/3845810/pexels-photo-3845810.jpeg?auto=compress&cs=tinysrgb&w=1600"
                  alt="Carmentis Healthcare Building"
                  className="relative z-10 rounded-lg shadow-xl"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <Activity className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Core Values</h2>
            <p className="text-gray-600">
              These principles guide every aspect of our work, from research and development to customer service.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Award className="h-10 w-10 text-blue-600" />,
                title: 'Excellence',
                description: 'We are committed to the highest standards of quality in everything we do, from research to manufacturing.',
              },
              {
                icon: <Users className="h-10 w-10 text-blue-600" />,
                title: 'Patient-Centered',
                description: 'Patients are at the heart of our mission. Their needs drive our innovation and development processes.',
              },
              {
                icon: <Globe className="h-10 w-10 text-blue-600" />,
                title: 'Global Impact',
                description: 'We develop solutions that address healthcare challenges across different populations and regions.',
              },
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-8 rounded-lg shadow-md"
              >
                <div className="inline-flex items-center justify-center p-3 bg-blue-50 rounded-full mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Company Timeline */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Journey</h2>
            <p className="text-gray-600">
              Tracing the evolution of Carmentis Healthcare from a small startup to a global leader in medical innovation.
            </p>
          </div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 h-full w-0.5 bg-blue-200 transform md:translate-x-px"></div>

            <div className="space-y-12">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                  className={`flex flex-col ${
                    index % 2 === 0
                      ? 'md:flex-row'
                      : 'md:flex-row-reverse'
                  } items-center`}
                >
                  <div className="md:w-1/2 p-4 flex items-center justify-end">
                    <div className={`w-full md:max-w-md ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                      <div className="inline-block px-4 py-2 bg-blue-600 text-white rounded-md mb-2">
                        {item.year}
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                  
                  <div className="mx-4 my-2 md:mx-0 md:my-0 relative">
                    <div className="h-8 w-8 rounded-full border-4 border-blue-200 bg-blue-600 z-10 relative"></div>
                  </div>
                  
                  <div className="md:w-1/2 p-4"></div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Join us in revolutionizing healthcare</h2>
          <p className="text-blue-100 max-w-2xl mx-auto mb-8">
            Learn more about how our innovative products are changing lives around the world.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="/vision" className="btn bg-white text-blue-700 hover:bg-blue-50">
              Our Vision <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a href="/contact" className="btn border border-white text-white hover:bg-white/10">
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;