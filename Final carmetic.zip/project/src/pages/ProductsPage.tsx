import { useState } from 'react';
import { motion } from 'framer-motion';
import ProductCard from '../components/ProductCard';
import { ArrowRight, Search } from 'lucide-react';

const ProductsPage = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const productCategories = [
    { id: 'all', name: 'All Products' },
    { id: 'diabetic', name: 'Diabetic' },
    { id: 'cardiac', name: 'Cardiac' },
    { id: 'hypertension', name: 'Hypertension' },
    { id: 'general', name: 'General' },
  ];

  const products = [
    // Diabetic Products
    {
      name: 'CARLIPRIDE M1',
      category: 'diabetic',
      description: 'METFORMIN 500MG + GLIMEPRIDE 1MG SR TAB - First-line treatment for type 2 diabetes with improved glycemic control',
      image: 'public/images/8.CARLIPRIDE M1.jpg',
    },
    {
      name: 'CARLIPRIDE M2',
      category: 'diabetic',
      description: 'METFORMIN 500MG + GLIMEPRIDE 2MG SR TAB - Intermediate strength medication for moderate type 2 diabetes',
      image: 'public/images/9.CARLIPRIDE M2.jpg',
    },
    {
      name: 'CARLIPRIDE M3',
      category: 'diabetic',
      description: 'METFORMIN 500MG + GLIMEPRIDE 3MG SR TAB - Maximum strength formula for advanced type 2 diabetes management',
      image: 'public/images/10.CARLIPRIDE M3.jpg',
    },
    {
      name: 'CARLIPRIDE MV1',
      category: 'diabetic',
      description: 'METFORMIN 500MG + GLIMEPRIDE 1MG + VOGLIBOSE 0.2 SR TAB - Specialized triple combination formula',
      image: 'public/images/11.CARLIPRIDE MV1.jpg',
    },
    {
      name: 'CARLIPRIDE-MV2',
      category: 'diabetic',
      description: 'METFORMIN 500MG + GLIMEPRIDE 2MG + VOGLIBOSE 0.2 SR TAB - Advanced triple combination for comprehensive diabetic care',
      image: 'public/images/12.CARLIPRIDE MV2.jpg',
    },
    {
      name: 'VYRAGLIPT OD',
      category: 'diabetic',
      description: 'VILDAGLIPTIN 100MG TAB - Once-daily DPP-4 inhibitor for type 2 diabetes management',
      image: 'public/images/37.VYRAGLIPT OD.jpg',
    },
    
    // Cardiac Products
    {
      name: 'CARLISTAT CV 10/75',
      category: 'cardiac',
      description: 'ROSUVASTATIN 10MG + COLPIDOGREL 75MG CAP - Comprehensive cardiovascular protection',
      image: 'public/images/13.CARLISTAT-CV-10.jpg',
    },
    {
      name: 'CARLISTAT-20MG',
      category: 'cardiac',
      description: 'ROSUVASTATIN 20MG TAB - High-potency statin for cholesterol management',
      image: 'public/images/14.CARLISTAT-20.jpg',
    },
    {
      name: 'CARLISTAT-ASP',
      category: 'cardiac',
      description: 'ROSUVASTATIN 10MG + ASPIRIN 75MG CAP - Dual action for heart protection',
      image: 'public/images/15.CARLISTAT-ASP 10.jpg',
    },
    {
      name: 'CARLISTAT-GOLD 10MG',
      category: 'cardiac',
      description: 'ROSUVASTATIN 10MG + ASPIRIN 75MG CAP + COLPIDOGREL 75MG CAP - Triple combination for comprehensive cardiac care',
      image: 'public/images/16.CARLISTAT-GOLD 10.jpg',
    },
    {
      name: 'CARLISTAT-GOLD 20MG',
      category: 'cardiac',
      description: 'ROSUVASTATIN 20MG + ASPIRIN 75MG CAP + COLPIDOGREL 75MG CAP - High-strength triple therapy',
      image: 'public/images/17.CARLISTAT-GOLD 20.jpg',
    },
    {
      name: 'ARNIHALT',
      category: 'cardiac',
      description: 'SACUBITRIL 49MG + VALSARTAN 51MG TAB - Advanced treatment for heart failure',
      image: 'public/images/1.ARNIHALT.jpg',
    },
    {
      name: 'NITROGRANT',
      category: 'cardiac',
      description: 'NITROGLYCERIN 2.6MG - Fast-acting relief for angina',
      image: 'public/images/46.NITROGRAND.jpg',
    },
    {
      name: 'TICAQUEEN',
      category: 'cardiac',
      description: 'TICAGRELOR 90MG TAB - Potent platelet inhibition for acute coronary syndrome',
      image: 'public/images/35.TICAQUEEN.jpg',
    },
    
    // Hypertension Products
    {
      name: 'ZICARTEL - 80 H',
      category: 'hypertension',
      description: 'TELMISARTAN 80MG + HYDROCHLOROTHIAZIDE 12.5 MG TAB - High-strength combination for resistant hypertension',
      image: 'public/images/39.ZICARTEL 80H.jpg',
    },
    {
      name: 'ZICARTEL 40',
      category: 'hypertension',
      description: 'TELMISARTAN 40MG TAB - Essential hypertension management',
      image: 'public/images/40.ZICARTEL 40.jpg',
    },
    {
      name: 'ZICARTEL CL',
      category: 'hypertension',
      description: 'TELMISARTAN 40MG + CILNIDIPINE 10MG TAB - Dual mechanism blood pressure control',
      image: 'public/images/41.ZICARTEL CL.jpg',
    },
    {
      name: 'ZICARTEL H',
      category: 'hypertension',
      description: 'TELMISARTAN 40MG + HYDROCHLOROTHIAZIDE 12.5 MG TAB - Combination therapy for enhanced efficacy',
      image: 'public/images/42.ZICARTEL H.jpg',
    },
    {
      name: 'ZICARTEL TRIO S',
      category: 'hypertension',
      description: 'TELMISARTAN 40MG + CILNIDIPINE 10MG + CHLORTHALIDONE 6.25MG TAB - Triple therapy for resistant hypertension',
      image: 'public/images/43.ZICARTEL TRIO S.jpg',
    },
    {
      name: 'PRAZOFIVE-XL',
      category: 'hypertension',
      description: 'PRAZOSIN HYDROCHLORIDE 5MG - Extended-release alpha blocker for hypertension',
      image: 'public/images/45.PRAZOFIVE-XL.jpg',
    },
    {
      name: 'BISOGILE 2.5',
      category: 'hypertension',
      description: 'BISOPROLOL 2.5 MG TAB - Selective beta blocker for hypertension management',
      image: 'public/images/3.BISOGILE 2.5.jpg',
    },
    {
      name: 'BISOGILE-T',
      category: 'hypertension',
      description: 'BISOPROLOL FUMARATE 2.5MG + TELMISARTAN 40MG TAB - Dual mechanism blood pressure control',
      image: 'public/images/4.BOSOGILE-T.jpg',
    },
    {
      name: 'BISOGILE-AM',
      category: 'hypertension',
      description: 'BISOPROLOL FUMARATE 2.5MG + AMLODIPINE 5MG TAB - Beta blocker and calcium channel blocker combination',
      image: 'public/images/5.BISOGILE-AM.jpg',
    },

    // General Products
    {
      name: 'BESTFOLATE',
      category: 'general',
      description: 'BIOTIN 5MG + L-METHYLFOLATE 1MG + METHYLCOBALAMIN 1500MG + PYRIDOXAL 5 PHOSPHATE 0.5MG TAB',
      image: 'public/images/2.BESTFOLATE TAB.jpg',
    },
    {
      name: 'BRYNITE',
      category: 'general',
      description: 'MULTIVITAMINE, MULTIMINARELS, ANTIOXIDENT, VIT B12 ADVANTAGE CAP',
      image: 'public/images/6.BRYNITE CAP.jpg',
    },
    {
      name: 'BRYNITE CD',
      category: 'general',
      description: 'METHYLCOBALAMIN 1500MG + AIPHA LIPOIC ACID 100MG + PYRIDOXINE 3MG + FOLIC ACID 1.5MG + VIT D3 1000IU TAB',
      image: 'public/images/7.BRYNITE CD TAB.jpg',
    },
    {
      name: 'CARLIX PRO',
      category: 'general',
      description: 'PROTEIN POWDER 29 VITAL NUTRIENTS & MINERALS',
      image: 'public/images/18.CARLIX PRO.jpg',
    },
    {
      name: 'CILAHOPE-10MG',
      category: 'general',
      description: 'CLINIDIPINE 10MG TAB',
      image: 'public/images/19.CILAHOPE-10.jpg',
    },
    {
      name: 'CRISTAVERT PLUS',
      category: 'general',
      description: 'CINNARIZINE 20MG + DIMENHYDRINATE 40MG TAB',
      image: 'public/images/20.CRISTAVERT-PLUS.jpg',
    },
    {
      name: 'ESLOCARM',
      category: 'general',
      description: 'ESCITALOPRAM 10MG + CLONAZEPAM 0.5MG TAB',
      image: 'public/images/21.ESLOCARM.jpg',
    },
    {
      name: 'GABAICE-NT 100MG',
      category: 'general',
      description: 'GABAPENTINE 100MG + NORTRIPTYLINE 10MG TAB',
      image: 'public/images/22.GABAICE NT 100.jpg',
    },
    {
      name: 'INFE SKIN',
      category: 'general',
      description: 'MUPIROCIN 2% W/w GEL',
      image: 'public/images/23.INFE SKIN.jpg',
    },
    {
      name: 'KHALF-LS-SYP',
      category: 'general',
      description: 'LEVOSALBUTAMOL 1MG + AMBROXOL 30MG + GUAIPHENSIN 50MG SYRUP',
      image: 'public/images/24.KHALF-LS.jpg',
    },
    {
      name: 'MICTICOOL SYP',
      category: 'general',
      description: 'D-MANNOE 300MG + CRANBERRY EXTRACT 200MG SYRUP',
      image: 'public/images/25.MICTICOOL SYRP.jpg',
    },
    {
      name: 'NEPTIDOX-OD',
      category: 'general',
      description: 'DOXYLAMINE SUCCINATE 20MG + PYRIDOXINE HYDROCHLORIDE 20MG + FOLIC ACID 5MG TAB',
      image: 'public/images/26.NEPTIDOX-OD.jpg',
    },
    {
      name: 'NEPTIFIZZ',
      category: 'general',
      description: 'SODIUM ALIGINATE 250MG + SODIUM BICARBONATE 133.5MG + CAICIUM CARBONATE 80MG SYRUP',
      image: 'public/images/27.NEPTIFIZZ.jpg',
    },
    {
      name: 'NEPTIPRIDE MV 2.3',
      category: 'general',
      description: 'VOGLIBOSE, GLIMIPRIDE AND METFORMIN HYDROCHLORIDE SR TAB',
      image: 'public/images/29.NEPTIPRIDE MV 2.3.jpg',
    },
    {
      name: 'NEPTIROSE',
      category: 'general',
      description: 'EVENING PRIMROSE OIL 500MG + COD LIVER OIL 300MG SOFT GEL CAP',
      image: 'public/images/30.NEPTIROSE.jpg',
    },
    {
      name: 'NEPTUNEX-D3',
      category: 'general',
      description: 'CAICIUM CARBONATE 500MG + VITAMIN D3 250MG TAB',
      image: 'public/images/31.NEPTUNEX D3.jpg',
    },
    {
      name: 'NIKMONT',
      category: 'general',
      description: 'LEVOCETRIZINE 5MG + MONTELUKAST 10MG TAB',
      image: 'public/images/32.NIKMOUNT.jpg',
    },
    {
      name: 'NIKPOD-200',
      category: 'general',
      description: 'CEFPODOXIME PROXETIL 200MG DISPERIBLE TAB',
      image: 'public/images/33.NIKPOD.jpg',
    },
    {
      name: 'PLUTIRON GOLD',
      category: 'general',
      description: 'FERROUS PYROPHOSPHATE [LIPOSOMAL IRON 30MG] + VIT C 50MG + VIT B12 0.5MG + FOLIC ACID 200 + ZINC 12MG TAB',
      image: 'public/images/34.PLUTIRON GOLD.jpg',
    },
    {
      name: 'VOLNISPAS',
      category: 'general',
      description: 'DROTAVERINE 80MG + MEFENAMIC ACID 50MG TAB',
      image: 'public/images/36.VOLINISPAS.jpg',
    },
    {
      name: 'RAPIKAR-D',
      category: 'general',
      description: 'RABEPRAZOLE 20MG + DOMPERIDONE 30MG',
      image: 'public/images/38.RAPIKAR-D.jpg',
    },
    {
      name: 'ZESMOCAR D',
      category: 'general',
      description: 'ESOMEPRAZOLE 40MG + DOMPERIDONE 30MG SR CAP',
      image: 'public/images/47.ZESMOCAR-D.jpg',
    },
    {
      name: 'GEO-CRUZ',
      category: 'general',
      description: 'OFLOXACIN 200MG + ORNIDAZOLE 500MG + LACTIC ACID BACILLUS 120 MILLION',
      image: 'public/images/44.GEO CRUZ.jpg',
    },
  ];

  // Filter products based on active tab and search query
  const filteredProducts = products.filter((product) => {
    const matchesTab = activeTab === 'all' || product.category === activeTab;
    const matchesSearch = 
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesTab && matchesSearch;
  });

  return (
    <div className="pt-24 pb-20">
      {/* Header */}
      <section className="bg-blue-600 py-16 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Our Products</h1>
          <p className="text-blue-100 max-w-2xl">
            Discover our comprehensive range of innovative pharmaceuticals designed to improve patient outcomes 
            and quality of life across multiple therapeutic areas.
          </p>
        </div>
      </section>

      {/* Products Content */}
      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4">
          {/* Search and Filter */}
          <div className="mb-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="relative w-full md:w-80">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
            </div>
            
            {/* Category Tabs */}
            <div className="flex flex-wrap justify-center gap-2">
              {productCategories.map((category) => (
                <button
                  key={category.id}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === category.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-slate-700 hover:bg-slate-100'
                  }`}
                  onClick={() => setActiveTab(category.id)}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product, index) => (
              <ProductCard
                key={`${product.category}-${product.name}`}
                name={product.name}
                description={product.description}
                image={product.image}
                category={
                  product.category === 'diabetic'
                    ? 'Diabetic'
                    : product.category === 'cardiac'
                    ? 'Cardiac'
                    : product.category === 'hypertension'
                    ? 'Hypertension'
                    : 'General'
                }
                delay={index * 0.02}
              />
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-16">
              <p className="text-slate-500 text-lg mb-4">No products found matching your criteria.</p>
              <button
                onClick={() => {
                  setActiveTab('all');
                  setSearchQuery('');
                }}
                className="btn btn-outline"
              >
                Show all products
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Need help finding the right product?</h2>
          <p className="text-slate-600 max-w-2xl mx-auto mb-8">
            Our medical experts are available to assist you in selecting the most appropriate 
            treatment options for your specific needs.
          </p>
          <a href="/contact" className="btn btn-primary">
            Contact Our Team <ArrowRight className="ml-2 h-5 w-5" />
          </a>
        </div>
      </section>
    </div>
  );
};

export default ProductsPage;