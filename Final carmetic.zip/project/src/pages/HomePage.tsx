import { motion } from 'framer-motion';
import { ArrowRight, Shield, Microscope, Award } from 'lucide-react';

const HomePage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="min-h-screen relative flex items-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container relative z-10 mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
                Tomorrow's Medicine, <span className="text-blue-600">Today</span>
              </h1>
              <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
                Pioneering innovative healthcare solutions for diabetic, cardiac, and hypertension management
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.a
                  href="/products"
                  whileHover={{ scale: 1.02 }}
                  className="btn btn-primary"
                >
                  Explore Products <ArrowRight className="ml-2 h-5 w-5" />
                </motion.a>
                <motion.a
                  href="/contact"
                  whileHover={{ scale: 1.02 }}
                  className="btn btn-outline"
                >
                  Contact Us
                </motion.a>
              </div>
            </motion.div>

            {/* Feature Cards */}
            <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: <Shield className="h-8 w-8 text-blue-600" />,
                  title: 'Trusted Quality',
                  description: 'Products meeting highest international standards for safety and efficacy',
                },
                {
                  icon: <Microscope className="h-8 w-8 text-blue-600" />,
                  title: 'Research Driven',
                  description: 'Continuous innovation based on cutting-edge medical research',
                },
                {
                  icon: <Award className="h-8 w-8 text-blue-600" />,
                  title: 'Patient Focused',
                  description: 'Designed with patient comfort and compliance as priorities',
                },
              ].map((card, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                  className="card p-8 text-center"
                >
                  <div className="inline-flex items-center justify-center p-4 bg-blue-50 rounded-full mb-4">
                    {card.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">{card.title}</h3>
                  <p className="text-slate-600">{card.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Featured Products</h2>
            <p className="text-slate-600">
              Discover our most advanced and effective solutions for managing chronic conditions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                category: 'Diabetic',
                product: 'Carlipride M2',
                description: 'Advanced glucose management for type 2 diabetes',
              },
              {
                category: 'Cardiac',
                product: 'Carlistat 40',
                description: 'Breakthrough treatment for cardiac rhythm management',
              },
              {
                category: 'Hypertension',
                product: 'Zicartel H40',
                description: 'Complete hypertension control with fewer side effects',
              },
            ].map((product, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="card card-hover p-8"
              >
                <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
                  {product.category}
                </span>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">{product.product}</h3>
                <p className="text-slate-600 mb-6">{product.description}</p>
                <a
                  href={`/products#${product.category.toLowerCase()}`}
                  className="inline-flex items-center text-blue-600 font-medium hover:text-blue-700"
                >
                  Learn more <ArrowRight className="ml-1 h-4 w-4" />
                </a>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <a href="/products" className="btn btn-outline">
              View All Products
            </a>
          </div>
        </div>
      </section>

      {/* Innovation Section */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="md:w-1/2"
            >
              <h2 className="text-3xl font-bold text-slate-900 mb-6">
                Driving Innovation in Medical Science
              </h2>
              <p className="text-slate-600 mb-8">
                At Carmentis Healthcare, we combine advanced research with cutting-edge technology to develop solutions 
                that improve patient outcomes and quality of life.
              </p>
              
              <div className="space-y-4 mb-8">
                {[
                  'State-of-the-art research facilities',
                  'Collaboration with leading medical institutions',
                  'Patient-centered product development',
                  'Rigorous clinical testing protocols',
                ].map((item, index) => (
                  <div key={index} className="flex items-center">
                    <div className="flex-shrink-0 h-2 w-2 rounded-full bg-blue-600 mr-3"></div>
                    <span className="text-slate-700">{item}</span>
                  </div>
                ))}
              </div>
              
              <a href="/vision" className="btn btn-primary">
                Our Vision <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="md:w-1/2"
            >
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <img
                  src="https://images.pexels.com/photos/8376151/pexels-photo-8376151.jpeg?auto=compress&cs=tinysrgb&w=1600"
                  alt="Medical Research"
                  className="w-full h-auto rounded-lg"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to experience the future of healthcare?</h2>
          <p className="text-blue-100 max-w-2xl mx-auto mb-8">
            Contact our team of healthcare specialists to learn more about our innovative products and how they can help improve patient outcomes.
          </p>
          <a href="/contact" className="btn bg-white text-blue-600 hover:bg-slate-50">
            Get in Touch
          </a>
        </div>
      </section>
    </div>
  );
};

export default HomePage;