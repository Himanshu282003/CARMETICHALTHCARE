import { motion } from 'framer-motion';
import { Microscope, FlaskRound as Flask, BarChart4, ArrowRight, Brain, HeartPulse, Database } from 'lucide-react';

const VisionPage = () => {
  return (
    <div className="pt-24 pb-20">
      {/* Header */}
      <section className="bg-gradient-to-r from-blue-700 to-blue-500 py-16 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Our Vision</h1>
          <p className="text-blue-100 max-w-2xl">
            Striving to be leading player in pharmaceutical industry through innovation and by providing high-quality medicicines at affordable prices for chronic diseases.
          </p>
        </div>
      </section>

      {/* Vision Statement */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8 leading-tight">
              "To transform healthcare through innovation, making advanced medical treatments accessible to all."
            </h2>
            <p className="text-gray-600 text-lg mb-8">
              At Carmentis Healthcare, we envision a future where medical breakthroughs are not only
              cutting-edge but also accessible and affordable to patients worldwide. We are committed
              to pioneering the next generation of treatments for chronic conditions, improving quality
              of life and extending healthy lifespans around the globe.
            </p>
            <div className="h-0.5 w-32 bg-blue-500 mx-auto"></div>
          </motion.div>
        </div>
      </section>

      {/* Strategic Pillars */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Strategic Pillars</h2>
            <p className="text-gray-600">
              Our long-term strategy rests on these key pillars that guide our research, development, and business operations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Microscope className="h-12 w-12 text-blue-600" />,
                title: 'Research Excellence',
                description: 'Investing in groundbreaking research to discover new treatments for chronic conditions.',
                points: [
                  'State-of-the-art laboratory facilities',
                  'Partnerships with leading academic institutions',
                  'Focus on novel drug delivery mechanisms',
                  'Biomarker identification for personalized medicine',
                ],
              },
              {
                icon: <HeartPulse className="h-12 w-12 text-blue-600" />,
                title: 'Patient-Centered Innovation',
                description: 'Developing products based on deep understanding of patient needs and experiences.',
                points: [
                  'Patient advisory boards for product development',
                  'Focus on reducing treatment side effects',
                  'Improving medication adherence through design',
                  'Quality of life metrics in all clinical trials',
                ],
              },
              {
                icon: <Database className="h-12 w-12 text-blue-600" />,
                title: 'Global Accessibility',
                description: 'Making advanced treatments available and affordable to patients worldwide.',
                points: [
                  'Tiered pricing models for different markets',
                  'Local manufacturing partnerships',
                  'Humanitarian programs for underserved regions',
                  'Streamlined regulatory approval processes',
                ],
              },
            ].map((pillar, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-8 rounded-lg shadow-md"
              >
                <div className="inline-flex items-center justify-center p-4 bg-blue-50 rounded-full mb-6">
                  {pillar.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{pillar.title}</h3>
                <p className="text-gray-600 mb-6">{pillar.description}</p>
                <ul className="space-y-2">
                  {pillar.points.map((point, i) => (
                    <li key={i} className="flex items-start">
                      <div className="flex-shrink-0 h-5 w-5 rounded-full bg-blue-100 flex items-center justify-center mt-0.5">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-3 w-3 text-blue-600"
                          viewBox="0 0 20 20"
                          fill="currentColor"
                        >
                          <path
                            fillRule="evenodd"
                            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                            clipRule="evenodd"
                          />
                        </svg>
                      </div>
                      <span className="ml-2 text-gray-600 text-sm">{point}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Future Innovation */}
      <section className="py-16 bg-white overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="md:w-1/2 md:pr-12 mb-8 md:mb-0"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Future Innovations</h2>
              <p className="text-gray-700 mb-6">
                At Carmentis Healthcare, we're not just focused on today's treatments but are actively 
                developing the medical technologies of tomorrow. Our innovation pipeline includes several 
                exciting frontiers that will revolutionize how chronic conditions are managed.
              </p>
              
              <div className="space-y-6">
                {[
                  {
                    icon: <Brain className="h-6 w-6 text-blue-600" />,
                    title: 'AI-Powered Medication Optimization',
                    description:
                      'Using artificial intelligence to analyze patient data and optimize medication dosing and combinations for personalized treatment plans.',
                  },
                  {
                    icon: <Flask className="h-6 w-6 text-blue-600" />,
                    title: 'Smart Delivery Systems',
                    description:
                      'Developing implantable and wearable devices that monitor health markers in real-time and release medication precisely when needed.',
                  },
                  {
                    icon: <BarChart4 className="h-6 w-6 text-blue-600" />,
                    title: 'Preventive Therapies',
                    description:
                      'Creating treatments that address the root causes of chronic conditions before symptoms develop, potentially preventing disease onset entirely.',
                  },
                ].map((innovation, index) => (
                  <div key={index} className="flex">
                    <div className="flex-shrink-0 h-12 w-12 rounded-full bg-blue-50 flex items-center justify-center mr-4">
                      {innovation.icon}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">{innovation.title}</h3>
                      <p className="text-gray-600 text-sm">{innovation.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="md:w-1/2"
            >
              <div className="relative">
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-blue-100 rounded-lg z-0 opacity-70"></div>
                <div className="absolute -bottom-4 -left-4 w-24 h-24 bg-cyan-100 rounded-lg z-0 opacity-70"></div>
                <img
                  src="https://images.pexels.com/photos/4226119/pexels-photo-4226119.jpeg?auto=compress&cs=tinysrgb&w=1600"
                  alt="Future Medical Innovation"
                  className="relative z-10 rounded-lg shadow-xl"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Research Initiatives */}
      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Research Initiatives</h2>
            <p className="text-gray-600">
              Our commitment to advancing medical science extends beyond product development to fundamental research 
              that expands our understanding of disease mechanisms and treatment approaches.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Diabetes Reversal Program',
                description:
                  'Investigating novel compounds that may help regenerate pancreatic beta cells and potentially reverse type 2 diabetes progression.',
                status: 'Phase 2 Clinical Trials',
              },
              {
                title: 'Cardiac Regeneration',
                description:
                  'Developing treatments that promote heart tissue regeneration after damage from heart attacks, potentially reducing long-term cardiac complications.',
                status: 'Pre-clinical Research',
              },
              {
                title: 'Hypertension Gene Therapy',
                description:
                  'Exploring targeted gene therapy approaches that could provide long-term blood pressure regulation with minimal side effects.',
                status: 'Early Research',
              },
            ].map((initiative, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-8 rounded-lg shadow-md"
              >
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{initiative.title}</h3>
                <p className="text-gray-600 mb-4">{initiative.description}</p>
                <div className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                  {initiative.status}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Responsibility */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col-reverse md:flex-row items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="md:w-1/2 mt-10 md:mt-0"
            >
              <div className="relative">
                <div className="grid grid-cols-2 gap-4">
                  <img
                    src="https://images.pexels.com/photos/3850679/pexels-photo-3850679.jpeg?auto=compress&cs=tinysrgb&w=1600"
                    alt="Community Health Initiative"
                    className="rounded-lg shadow-md"
                  />
                  <img
                    src="https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg?auto=compress&cs=tinysrgb&w=1600"
                    alt="Rural Healthcare Access"
                    className="rounded-lg shadow-md mt-8"
                  />
                  <img
                    src="https://images.pexels.com/photos/6823562/pexels-photo-6823562.jpeg?auto=compress&cs=tinysrgb&w=1600"
                    alt="Medical Research Investment"
                    className="rounded-lg shadow-md"
                  />
                  <img
                    src="https://images.pexels.com/photos/6823447/pexels-photo-6823447.jpeg?auto=compress&cs=tinysrgb&w=1600"
                    alt="Healthcare Education"
                    className="rounded-lg shadow-md mt-8"
                  />
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="md:w-1/2 md:pl-12"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Social Responsibility</h2>
              <p className="text-gray-700 mb-6">
                We believe that our responsibility extends beyond creating effective medications to ensuring that 
                healthcare innovations benefit all communities, especially those that are underserved or marginalized.
              </p>
              
              <div className="space-y-6">
                {[
                  'Medication access programs for low-income communities',
                  'Educational initiatives about chronic disease prevention',
                  'Support for healthcare infrastructure in developing regions',
                  'Research grants for neglected medical conditions',
                  'Environmental sustainability in our manufacturing processes',
                ].map((item, index) => (
                  <div key={index} className="flex items-start">
                    <div className="flex-shrink-0 h-5 w-5 rounded-full bg-blue-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-3 w-3 text-blue-600"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="ml-3 text-gray-600">{item}</span>
                  </div>
                ))}
              </div>
              
              <a href="/contact" className="btn btn-primary mt-8">
                Partner With Us <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Be Part of Our Vision</h2>
          <p className="text-blue-100 max-w-2xl mx-auto mb-8">
            Join us in our mission to transform healthcare through innovation and make advanced medical treatments 
            accessible to all. Let's create a healthier future together.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="/products" className="btn bg-white text-blue-700 hover:bg-blue-50">
              Explore Our Products <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a href="/contact" className="btn border border-white text-white hover:bg-white/10">
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default VisionPage;